package com.nseindia.b2.blogger.models;

import java.util.List;

import com.nseindia.b2.blogger.entities.Admin;

public class ResponseList {

	public String message;
	public List<Admin> admin;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Admin> getAdmin() {
		return admin;
	}

	public void setAdmin(List<Admin> admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "ResponseList [message=" + message + ", admin=" + admin + "]";
	}

}
