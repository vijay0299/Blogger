package com.nseindia.b2.blogger.services;

import java.util.List;

import com.nseindia.b2.blogger.entities.Admin;
//import com.nseindia.b2.blogger.models.RequestAdmin;

public interface AdminService {

	public List<Admin> getAll();

	public Admin get(Long id);

	public Admin put(Admin admin);

	public Admin update(Long id, Admin admin);

	public Admin delete(Long id);

}
