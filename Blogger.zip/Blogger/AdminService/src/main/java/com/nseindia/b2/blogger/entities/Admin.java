package com.nseindia.b2.blogger.entities;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.Entity;

//import java.util.List;
@Entity
public class Admin {
	@Id
	@GeneratedValue
	private Long id;
	private String name;
	private String title;
	private String summary;
	private String body;
//	private List<Admin> list;

	public Long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", title=" + title + ", summary=" + summary + ", body=" + body
				+ "]";
	}

//	public List<Admin> getList() {
//		return list;
//	}
//
//	public void setList(List<Admin> list) {
//		this.list = list;
//	}

}
