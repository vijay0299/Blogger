package com.nseindia.b2.blogger.repositories;

import org.springframework.data.repository.CrudRepository;

import com.nseindia.b2.blogger.entities.Admin;

public interface Repository extends CrudRepository<Admin,Long> {

}
